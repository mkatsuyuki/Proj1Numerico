#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "equations.h"
#include "methods.h"


//---------------------------------------//
double bissection(double* a, double* b, double fa, double fx);
//---------------------------------------//

const char* concatena_linha(double* bissection_results,double* secant_results, double* newton_results, double* halley_results, int i);

int main(void) {
  //Declaração de variáveis
  int i, tamanho;
  double a, b;
  double bissection_results[60];
  double secant_results[50];
  double newton_results[50];
  double halley_results[20];
  char resultados[100];

  
  //--------Método da Bissecção------------------------------------//
  //A função retorna o tamanho do vetor bissection_results após fazer o cálculo da raiz
  FILE *fp;
  fp=fopen("testeee.bin", "w+");

  printf("Metodo da Bisseccao:\n");
  printf("Equacao 1:\n");
  tamanho = f_bissection_method(0, 2, bissection_results);

  for(i=0;i<tamanho;i++){
    //printf("x:%.16f i:%d\n", bissection_results[i], i);
    fprintf(fp,"x:%.16f i:%d\n", bissection_results[i], i);
  }
  fclose(fp);
  
  printf("\nEquacao 2:\n");
  tamanho = g_bissection_method(1, 6, bissection_results);
  for(i=0;i<tamanho;i++){
    printf("x:%.16f i:%d\n", bissection_results[i], i);
  }
  
  
  printf("\nEquacao 3:\n");
  tamanho = h_bissection_method(-1, 2, bissection_results);
  for(i=0;i<tamanho;i++){
    printf("x:%.16f i:%d\n", bissection_results[i], i);
  }
  
  //--------Método da Secante----------------------------------------//
  printf("\nMetodo da Secante:\n");
  printf("Equacao 1:\n");
  tamanho = f_secant_method(0, 2, secant_results);
  for(i=0;i<tamanho;i++){
    printf("x:%.16f i:%d\n", secant_results[i], i);
  }
  
  
  printf("\nEquacao 2:\n");
  tamanho = g_secant_method(1, 5, secant_results);
  for(i=0;i<tamanho;i++){
    printf("x:%.16f i:%d\n", secant_results[i], i);
  }
  
  
  printf("\nEquacao 3:\n");
  tamanho = h_secant_method(1, 2, secant_results);
  for(i=0;i<tamanho;i++){
    printf("x:%.16f i:%d\n", secant_results[i], i);
  }
  
    //--------Método de Newton----------------------------------------//
  printf("\nMetodo de Newton:\n");
  printf("Equacao 1:\n");
  tamanho = f_newton_method(1, newton_results);
  for(i=0;i<tamanho;i++){
    printf("x:%.16f i:%d\n", newton_results[i], i);
  }
  
  
  printf("\nEquacao 2:\n");
  tamanho = g_newton_method(2, newton_results);
  for(i=0;i<tamanho;i++){
    printf("x:%.16f i:%d\n", newton_results[i], i);
  }
  
  
  printf("\nEquacao 3:\n");
  tamanho = h_newton_method(1, newton_results);
  for(i=0;i<tamanho;i++){
    printf("x:%.16f i:%d\n", newton_results[i], i);
  }
  
  //--------Método de Halley----------------------------------------//
  printf("\nMetodo de Halley:\n");
  printf("Equacao 1:\n");
    tamanho = f_halley_method(1, halley_results);
  for(i=0;i<tamanho;i++){
    printf("x:%.16f i:%d\n", halley_results[i], i);
  }
  
  
  printf("Equacao 2:\n");
    tamanho = g_halley_method(2, halley_results);
  for(i=0;i<tamanho;i++){
    printf("x:%.16f i:%d\n", halley_results[i], i);
  }
  
  
  printf("Equacao 3:\n");
    tamanho = h_halley_method(1, halley_results);
  for(i=0;i<tamanho;i++){
    printf("x:%.16f i:%d\n", halley_results[i], i);
  }
  return 0;
}

//---------------------------------------//

const char* concatena_linha(double* bissection_results,double* secant_results, double* newton_results, double* halley_results, int i){
  //char[200];
}